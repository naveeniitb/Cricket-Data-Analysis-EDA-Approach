
library(proto)
library(gsubfn)
library(RSQLite)
library(sqldf)
library(ggplot2)
library(dplyr)

#changing directory 
setwd("~/New folder/ipl_csv_male")

#reading all IPL matches data 
temp = list.files(pattern="*.csv")

x=read.csv(temp[1], header = FALSE,col.names=paste("V",seq_len(11)))

x$match=1
x$matchc=temp[1]

length(temp)

for (i in 2:816) {
  t=read.csv(temp[i], header = FALSE,col.names=paste("V",seq_len(11)))
  t$match=i
  t$matchc=temp[i]
  x=rbind(x,t)
}


m=filter(x,V.1=='ball')

detail=filter(x,V.1=='info')[,c(1,2,3,12,13)]
head(detail)

season=filter(detail,V.2=='season')[,c(3,4,5)]
head(season)

colnames(season)= c("season", "match", "matchc")

colnames(m)= c("Ball" ,"Inning" ,"Over" ,"Country" ,"P1" ,"P2" ,"B" ,"R" ,"R1" ,"Out" ,"Outp", "match", "matchc")
m$Over=as.numeric(m$Over)
m$Ball2=6*floor(m$Over)+10*(m$Over-floor(m$Over))
m$Ball3=as.character(round(10*(m$Over-floor(m$Over))))

m1=merge(m,season,"matchc")
tail(m1,2)

tail(m$Ball3,20)

colnames(m1)= c("matchc", "Ball" ,"Inning" ,"Over" ,"Country" ,"P1" ,"P2" ,"B" ,"R" ,"R1" ,"Out" ,"Outp", "match","Ball2","Ball3","season","match2")

m2019=filter(m1,season=='2019')
m2019$match=m2019$match-119

head(m2019[,c(3,4,9,10)],140)


#distribution of extra
extra=filter(m2019,R1==1)[,c(3,4,5,6,8,9,10,13,15)]
head(extra)
#distribution : which ball is extra
sqldf("select distinct Ball3,sum(R1) as n1, count(*) as n2 from extra group by Ball3 order by Ball3")

sqldf("select distinct B,sum(R1) as n1, count(*) as n2 from extra group by B order by n1")

sqldf("select distinct B,sum(R1+R) as n1, count(*) as n2 from m2019 group by B order by n1")

sqldf("select distinct B,sum(R1+R) as n1, count(*) as n2 from m2019 where R = 0 group by B order by n1")

sqldf("select distinct Country,sum(R1) as n1, count(*) as n2 from extra group by Country order by n1")

sqldf("select distinct match,Inning,sum(R1) as n1, count(*) as n2 from extra group by match,Inning
      order by n1")

run=filter(m2019,R1==0)[,c(3,4,5,6,8,9,10,14,15)]
head(run,20)

sqldf("select  Ball3,count(*) as n1 from run group by Ball3")

tail(m2019)

run$Ball4=floor(run$Ball2 - 2*floor((run$Ball2)/2)+.1)

tail(run$Ball4,10)


run %>% 
  group_by(run$Ball3) %>% 
  summarise(mean=mean(R), sd=sd(R),s=sum(R),min=min(R), med=median(R),q=quantile(R,probs=.75))

run %>% 
  group_by(run$Ball4) %>% 
  summarise(mean=mean(R), sd=sd(R),s=sum(R),min=min(R), med=median(R),q=quantile(R,probs=.75))

dot=filter(m2019,(R1+R)==0)[,c(1,2,3,4,5,6,8,9,10,13,15)]

dot1=sqldf("select distinct match,Inning,count(*) as num  
         from m2019 where (R1+R)==0 and Inning <=2 group by match,Inning order by match,Inning")

mean(dot1$num)
median(dot1$num)
var(dot1$num)


extra=sqldf("select distinct match,Inning,count(*) as num  
         from m2019 where R1==1 and Inning <=2 group by match,Inning order by match,Inning")

mean(extra$num)
median(extra$num)
var(extra$num)
sum(extra$num)

extra %>% 
  group_by(Inning) %>% 
  summarise(mean=mean(num), var=var(num),s=sum(num), med=median(num),q=quantile(num,probs=.25),
            min(num),max(num))



#number of matches by each country
sqldf("select distinct Country,count(distinct match) as s  
         from m2019 group by Country order by Country")

min(m2019$match)
max(m2019$match)

#number of run in each over
run_over<-sqldf("select distinct match,Inning,Country,Outp , ceil(Over) as O, sum(R+R1) as run_per_over 
         from m2019 group by ceil(Over),match,Inning, Country order by match, Country")

tail(run_over,10)

mean(run_over$run_per_over)*2327/120

median(run_over$run_per_over)

cnt<-sqldf("select distinct Inning,count(*)/60 from m2019 where outp > ''
            group by Inning")
tail(cnt)

sqldf("select distinct Inning,sum(run_per_over) 
         from run_over group by Inning")

sqldf("select distinct Inning,sum(run_per_over) 
         from run_over group by Inning")





summary(run_over$run_per_over, m=mean(run_per_over,sd=sd(run_per_over)))

summary(m2019$R,m=mean(R),sd=sd(R))

run_over %>% 
  group_by(Country) %>% 
  summarise(mean=mean(run_per_over), sd=sd(run_per_over))

m2019 %>% 
  group_by(Country) %>% 
  summarise(mean=mean(R), sd=sd(R))


#odds ratio estimate
a=1.2381
b=0.897
c=1.7088

a/b
c/a
a-b
c-a

#EAIR estimate
a=1.716
b=1.444
c=2.026

a/b
c/a
a-b
c-a

a=8017
b=6226
c=10323
a/b
c/a
a-b
c-a


115.77/77
